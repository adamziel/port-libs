<?php
 declare(strict_types=1); namespace PortLibs\Pandoc; interface PdfSemanticRecordProcessor { public function name(): string; public function process(array $records): array; } 